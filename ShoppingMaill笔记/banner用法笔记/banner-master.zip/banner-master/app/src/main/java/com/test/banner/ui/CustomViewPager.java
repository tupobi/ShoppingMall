package com.test.banner.ui;

import android.content.Context;
import android.util.AttributeSet;

import com.youth.banner.view.BannerViewPager;


public class CustomViewPager extends BannerViewPager {
    // do something by yourself.

    public CustomViewPager(Context context) {
        super(context);
    }

    public CustomViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
